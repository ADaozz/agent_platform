---
name: Core System Interface
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#585f6c'
  on-secondary: '#ffffff'
  secondary-container: '#dce2f3'
  on-secondary-container: '#5e6572'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dce2f3'
  secondary-fixed-dim: '#c0c7d6'
  on-secondary-fixed: '#151c27'
  on-secondary-fixed-variant: '#404754'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  page-title:
    fontFamily: Noto Sans SC
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  module-title:
    fontFamily: Noto Sans SC
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body:
    fontFamily: Noto Sans SC
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label:
    fontFamily: Noto Sans SC
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
  mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar_width: 240px
  header_height: 56px
  container_padding: 24px
  gutter: 16px
  stack_gap: 8px
---

## Brand & Style

The design system is engineered for high-utility Enterprise IT Asset Management and CMDB environments. The aesthetic is strictly **Corporate / Modern**, prioritizing information density, rapid scanning, and operational clarity.

The visual language follows a "Function over Form" philosophy, utilizing a neutral, systematic approach to minimize cognitive load. It avoids decorative elements like glassmorphism or heavy gradients in favor of a rigid structural hierarchy. The UI should evoke a sense of reliability, precision, and technical authority, suitable for DevOps and System Administration workflows.

## Colors

The color palette is optimized for a high-density "Management Console" experience. 

- **Primary Canvas**: The background uses a subtle off-white to reduce eye strain, while cards and surface containers use pure white to create clear physical separation.
- **Brand Action**: The Primary Blue is reserved for calls to action, active states, and focus indicators.
- **Semantic Status**: Status colors are critical for system health monitoring. 
    - **Green (Running)**: Positive operational state.
    - **Blue (Creating)**: Active processes or informative notices.
    - **Gray (Stopped)**: Dormant or disabled assets.
    - **Orange (Warning)**: Destructive actions in progress or configuration warnings.
    - **Red (Error)**: Critical failures or immediate deletion actions.

## Typography

This design system uses **Noto Sans SC** (Source Han Sans) as the primary typeface to ensure exceptional legibility for technical Simplified Chinese characters.

- **Information Density**: Sizes are kept compact (14px base) to maximize the amount of data visible on a single screen without scrolling.
- **Hierarchy**: Use `Page Title` for main view headers and `Module Title` for section headers within cards.
- **Monospace**: For IP addresses, resource IDs, and code snippets, use a monospaced font to ensure character alignment and readability.
- **Alignment**: Standardize on left-alignment for all data points; use right-alignment only for numerical values in tables to facilitate comparison.

## Layout & Spacing

The layout follows a standard **Enterprise Shell** model:
1. **Sidebar (Left)**: Fixed 240px width. Contains the primary navigation (e.g., 仪表盘, 资产管理, 网络拓扑). Use a collapsed mode (64px) for power users.
2. **Header (Top)**: Fixed 56px height. Contains breadcrumbs, global search (搜索资源/文档), and user profile.
3. **Content Area**: Fluid width with 24px internal padding. 

The spacing rhythm is based on a **4px/8px grid**. Standardize gaps between related form elements at 8px, and gaps between unrelated modules/cards at 16px or 24px.

## Elevation & Depth

This design system utilizes **Tonal Layering** and **Low-Contrast Outlines** rather than heavy shadows.

- **Level 0 (Background)**: #F7F8FA. The base layer.
- **Level 1 (Cards/Surfaces)**: #FFFFFF with a 1px border (#E5E7EB). No shadow, or a very subtle 2px blur with 2% opacity.
- **Level 2 (Modals/Dropdowns)**: #FFFFFF with a 1px border and a medium ambient shadow (8px-16px blur, 8% opacity) to provide clear z-axis separation.
- **Active States**: Use a primary color border (2px) to indicate focus or selection on inputs and active navigation items.

## Shapes

The shape language is professional and geometric, utilizing varying corner radii to imply containment and hierarchy.

- **Functional Elements**: Buttons and Input fields use a **6px** radius for a modern but precise feel.
- **Containers**: Cards use an **8px** radius, while Modals use **10px** to feel slightly more prominent and separated from the background.
- **Status Indicators**: Tags/Pills must be fully rounded (**999px**) to distinguish them from interactive buttons and static labels at a glance.

## Components

### Buttons & Inputs
- **Primary Button**: Background #2563EB, Text #FFFFFF, 6px radius. Label: "确定" or "保存".
- **Ghost/Secondary Button**: Border #E5E7EB, Text #111827. Label: "取消" or "重置".
- **Input Fields**: Height 32px (Small) or 36px (Default). Placeholder text #9CA3AF. Label: "资源名称".

### Data Tables (Critical Component)
- **Header**: Light gray background (#F9FAFB), 12px Medium text, #6B7280.
- **Rows**: 1px bottom border only. Hover state background #F3F4F6.
- **Density**: Row height should be set to 40px for standard density, 32px for high-density views.

### Status Tags (Pills)
- Use light background tints of the status colors (10% opacity) with high-contrast text of the same hue.
- Example: **运行中** (Running) -> Bg: #D1FAE5, Text: #065F46.

### Cards
- White background, #E5E7EB border, 8px radius. 
- Use for grouping related asset details (e.g., "基本信息", "网络配置").

### Navigation Sidebar
- Vertical list. Active state: #EFF6FF background with a 2px blue left-border. 
- Icons: Line-art style (20px size).